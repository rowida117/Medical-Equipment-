import serial
import serial.tools.list_ports
import numpy as np
import matplotlib.pyplot as plt
import time

# Auto-detect Arduino Serial Port
def find_arduino():
    ports = list(serial.tools.list_ports.comports())
    for port in ports:
        if "Arduino" in port.description or "CH340" in port.description:
            return port.device
    return None

arduino_port = find_arduino()

if arduino_port is None:
    print("Error: Arduino not found. Check connection.")
    exit()

# Open Serial Connection
try:
    arduino = serial.Serial(port=arduino_port, baudrate=115200, timeout=1)
    print(f"Connected to Arduino on {arduino_port}")
except Exception as e:
    print("Error: Could not open serial port.")
    exit()

# Initialize Matplotlib Plot
plt.ion()
fig, ax = plt.subplots(figsize=(12, 5))
plt.show()

window_size = 500  # Adjusted for 1-second ECG waveform
x_data = np.linspace(0, 1, window_size)  # X-axis now represents 1 second
y_data = np.zeros(window_size)
line, = ax.plot(x_data, y_data, 'm', linewidth=2)

ax.set_ylim(-0.5, 2.5)
ax.set_xlim(0, 1)  # Display 1 second of ECG data
ax.set_xlabel("Time (s)")
ax.set_ylabel("ECG Signal")
ax.set_title("Live ECG Signal Based on Pulse Sensor")

# Moving average filter parameters
filter_size = 5
sensor_buffer = []

# Adaptive threshold parameters
baseline = 512  # Initial estimated baseline

# Improved BPM calculation with averaging
bpm_history = []
bpm_window = 5  # Number of readings to average

# Function to apply a moving average filter
def moving_average_filter(new_value):
    if len(sensor_buffer) >= filter_size:
        sensor_buffer.pop(0)
    sensor_buffer.append(new_value)
    return np.mean(sensor_buffer)

# Function to adjust threshold dynamically
def update_baseline(new_value):
    global baseline
    baseline = 0.9 * baseline + 0.1 * new_value  # Slowly adapts to changes

# Function to improve BPM estimation
def get_realistic_bpm(new_bpm):
    if new_bpm > 0:
        bpm_history.append(new_bpm)
    if len(bpm_history) > bpm_window:
        bpm_history.pop(0)
    return np.mean(bpm_history) if bpm_history else 0

# More realistic ECG waveform
def generate_realistic_ecg(bpm, sensor_value, num_points=200):
    t_values = np.linspace(0, 1, num_points)  # Time scale adjusted for 1 sec

    # Adjust amplitude based on sensor value
    amplitude_factor = (sensor_value - 500) / 300.0
    amplitude_factor = max(0, min(amplitude_factor, 1))

    # Generate ECG waves with improved accuracy
    P = 0.08 * amplitude_factor * np.exp(-((t_values - 0.16) / 0.04) ** 2)
    Q = -0.12 * amplitude_factor * np.exp(-((t_values - 0.45) / 0.02) ** 2)
    # R = 2.5 * amplitude_factor * np.exp(-((t_values - 0.48) / 0.01) ** 2)
    # S = -0.28 * amplitude_factor * np.exp(-((t_values - 0.52) / 0.02) ** 2)
    # T = 0.6 * amplitude_factor * np.exp(-((t_values - 0.75) / 0.1) ** 2)
    # ventricular tachycardia
    R =  5 * amplitude_factor * np.exp(-((t_values - 0.48) / 0.002) ** 2)  # Increase R-wave
    S = -0.9 * amplitude_factor * np.exp(-((t_values - 0.52) / 0.004) ** 2)  # Widen S-wave
    T = 0.9 * amplitude_factor * np.exp(-((t_values - 0.75) / 0.1) ** 2)
    bpm = 180
    return P + Q + R + S + T

# Live ECG Plotting Loop
try:
    while True:
        try:
            line_raw = arduino.readline().decode('utf-8').strip()
            if not line_raw:
                continue

            print(f"Received: {line_raw}")

            if "," not in line_raw or line_raw.count(",") != 1:
                print("Warning: Incorrect data format. Skipping.")
                continue

            try:
                sensor_value, bpm_str = line_raw.split(",")
                sensor_value = float(sensor_value.strip())
                bpm = float(bpm_str.strip()) if bpm_str.strip() else 0
            except ValueError:
                print("Error: Cannot convert received data. Skipping.")
                continue

            # Apply noise reduction using moving average filter
            sensor_value = moving_average_filter(sensor_value)

            # Dynamically adjust baseline for better touch sensitivity
            update_baseline(sensor_value)

            # Ensure beats are detected more accurately
            threshold = baseline + 50
            if sensor_value > threshold:
                bpm = 60000 / (bpm + 1) if bpm > 0 else 0
                bpm = get_realistic_bpm(bpm)

            # If no valid signal, force ECG flatline
            if bpm == 0:
                print("No Pulse Detected - Setting BPM to 0")
                y_data[:] = 0
            else:
                # Generate ECG waveform with improved accuracy
                new_ecg_segment = generate_realistic_ecg(bpm, sensor_value, num_points=200)

                # Shift old data left & append new ECG segment
                y_data = np.roll(y_data, -200)  # Slower shift for 1-second ECG wave
                y_data[-200:] = new_ecg_segment

            print(f"Sensor Value: {sensor_value}, Adjusted BPM: {bpm}")

            # Update the live plot dynamically
            line.set_ydata(y_data)
            ax.relim()
            ax.autoscale_view(True, True, True)
            fig.canvas.draw()
            fig.canvas.flush_events()
            plt.pause(0.01)

        except ValueError:
            print("Warning: Received invalid data. Skipping.")

except KeyboardInterrupt:
    print("\nStopping ECG simulation.")
    arduino.close()
    plt.close()