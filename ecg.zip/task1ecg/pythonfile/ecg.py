import serial
import serial.tools.list_ports
import numpy as np
import matplotlib.pyplot as plt
import time

# Auto-detect Arduino Serial Port
def find_arduino():
    ports = list(serial.tools.list_ports.comports())
    for port in ports:
        if "Arduino" in port.description or "CH340" in port.description:
            return port.device
    return None

arduino_port = find_arduino()

if arduino_port is None:
    print("Error: Arduino not found. Check connection.")
    exit()

# Open Serial Connection
try:
    arduino = serial.Serial(port=arduino_port, baudrate=115200, timeout=1)
    print(f"Connected to Arduino on {arduino_port}")
except Exception as e:
    print("Error: Could not open serial port.")
    exit()

# Initialize Matplotlib Plot
plt.ion()
fig, ax = plt.subplots(figsize=(12, 5))
plt.show()

window_size = 500  # Number of points in the ECG window
y_data = np.zeros(window_size)  # ECG values
start_time = time.time()  # Keep track of start time

# Create a moving x-axis that starts at 0
x_data = np.linspace(0, 1, window_size)
line, = ax.plot(x_data, y_data, 'm', linewidth=2)

ax.set_ylim(-0.5, 2.5)
ax.set_xlabel("Time (s)")
ax.set_ylabel("ECG Signal")
ax.set_title("Live ECG Signal Based on Pulse Sensor")

# BPM tracking
bpm_history = []
bpm_window = 5

# Function to calculate BPM error
def calculate_error(estimated_bpm, actual_bpm):
    if actual_bpm == 0:
        return 0
    return abs(estimated_bpm - actual_bpm) / actual_bpm * 100  # Percentage error

# Function to improve BPM estimation
def get_realistic_bpm(new_bpm):
    if new_bpm > 0:
        bpm_history.append(new_bpm)
    if len(bpm_history) > bpm_window:
        bpm_history.pop(0)
    return np.mean(bpm_history) if bpm_history else 0

# **ECG Function (NO CHANGES TO ECG SHAPE)**
def generate_realistic_ecg(bpm, sensor_value, num_points=200):
    t_values = np.linspace(0, 1, num_points)

    amplitude_factor = (sensor_value - 500) / 300.0
    amplitude_factor = max(0, min(amplitude_factor, 1))

    # Generate ECG waves normall
   # P = 0.1 * amplitude_factor * np.exp(-((t_values - 0.2) / 0.045) ** 2)  # Normal P-wave
    #Q = -0.15 * amplitude_factor * np.exp(-((t_values - 0.43) / 0.02) ** 2)  # Slightly sharper Q-wave
    #R = 1.8 * amplitude_factor * np.exp(-((t_values - 0.47) / 0.01) ** 2)  # Realistic R-wave height
    #S = -0.3 * amplitude_factor * np.exp(-((t_values - 0.5) / 0.015) ** 2)  # Normal S-wave
    #T = 0.5 * amplitude_factor * np.exp(-((t_values - 0.75) / 0.1) ** 2)  # Smooth T-wave repolarization

#tachycardiac values
    # Generate ECG waves for Ventricular Tachycardia (VT)
    P = 0.02 * amplitude_factor * np.exp(-((t_values - 0.2) / 0.06) ** 2)  # Very small or absent P-wave
    Q = -0.15 * amplitude_factor * np.exp(-((t_values - 0.42) / 0.04) ** 2)  # Wider Q-wave
    R = 2 * amplitude_factor * np.exp(-((t_values - 0.5) / 0.03) ** 2)  # Large, wide R-wave
    S = -0.6 * amplitude_factor * np.exp(-((t_values - 0.55) / 0.03) ** 2)  # Deep S-wave
    T = 0.3 * amplitude_factor * np.exp(-((t_values - 0.8) / 0.15) ** 2)  # Inverted or weak T-wave

    # Set BPM higher to simulate fast rhythm
    bpm = np.random.randint(140, 200)

    return P + Q + R + S + T

# **Live ECG Plotting Loop (Fixed)**
try:
    while True:
        try:
            line_raw = arduino.readline().decode('utf-8').strip()
            if not line_raw:
                continue

            if "," not in line_raw or line_raw.count(",") != 1:
                continue

            try:
                sensor_value, bpm_str = line_raw.split(",")
                sensor_value = float(sensor_value.strip())
                bpm = float(bpm_str.strip()) if bpm_str.strip() else 0
            except ValueError:
                continue

            # Ensure beats are detected more accurately
            threshold = 600  # Adjust this threshold based on sensor calibration
            if sensor_value > threshold:
                estimated_bpm = 60000 / (bpm + 1) if bpm > 0 else 0
                estimated_bpm = get_realistic_bpm(estimated_bpm)

            else:
                estimated_bpm = 0

            # Map BPM to normal range (60-100 BPM)
            estimated_bpm =get_realistic_bpm(estimated_bpm)

            # Calculate error
            bpm_error = calculate_error(estimated_bpm, bpm)

            # Generate ECG waveform
            if estimated_bpm == 0:
                y_data = np.roll(y_data, -100)  # Keep scrolling even if no new data
            else:
                new_ecg_segment = generate_realistic_ecg(estimated_bpm, sensor_value, num_points=200)
                y_data = np.roll(y_data, -200)
                y_data[-200:] = new_ecg_segment

            # **Dynamic Time Axis**
            current_time = time.time() - start_time  # Get current elapsed time
            x_data = np.linspace(current_time - 1, current_time, window_size)  # Shift x-axis dynamically

            line.set_xdata(x_data)
            line.set_ydata(y_data)

            # Update GUI title based on whether pulse is detected or not
            if estimated_bpm == 0:
                ax.set_title("Live ECG Signal - No Pulse Detected")
            else:
                ax.set_title(f"Live ECG Signal - BPM: {estimated_bpm:.1f} | Error: {bpm_error:.2f}%")

            # Update plot dynamically
            ax.set_xlim(x_data[0], x_data[-1])  # Ensure x-axis shifts with time
            ax.relim()
            ax.autoscale_view(True, True, True)
            fig.canvas.draw()
            fig.canvas.flush_events()
            plt.pause(0.01)

        except ValueError:
            continue

except KeyboardInterrupt:
    print("\nStopping ECG simulation.")
    arduino.close()
    plt.close()
